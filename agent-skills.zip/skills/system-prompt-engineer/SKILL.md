---
name: system-prompt-engineer
description: Craft detailed, senior-level system prompts for AI agents. Use this skill when creating or improving agent instructions, designing multi-agent systems, or ensuring professional-grade prompt engineering. Triggers on phrases like "create system prompt", "improve agent instructions", "prompt engineering", "write agent prompt".
---

# System Prompt Engineer

## Overview

This skill provides comprehensive guidance for crafting professional, senior-level system prompts for AI agents. It encapsulates best practices from prompt engineering to help you create clear, effective, and maintainable agent instructions.

### What This Skill Does

- Guides you through the complete system prompt creation process
- Provides templates for different agent archetypes
- Offers best practices and quality standards
- Helps you avoid common pitfalls
- Ensures your prompts are production-ready

### When to Use This Skill

Use this skill when you need to:

- Create a new system prompt from scratch
- Improve an existing agent's instructions
- Design a multi-agent system architecture
- Standardize prompts across your organization
- Debug agent behavior issues
- Onboard new team members to prompt engineering

### Why Quality System Prompts Matter

A well-crafted system prompt is the foundation of reliable AI agent behavior. Quality prompts:

1. **Reduce ambiguity** - Clear instructions minimize misinterpretation
2. **Improve consistency** - Agents produce predictable outputs
3. **Enhance reliability** - Fewer edge cases and failures
4. **Enable collaboration** - Teams can understand and modify prompts
5. **Scale effectively** - Good prompts work across different contexts

---

## System Prompt Anatomy

A professional system prompt consists of several core components. Each serves a specific purpose in guiding agent behavior.

### 1. Role Definition

Clearly define who or what the agent is. Be specific about its identity, expertise level, and domain.

```
You are a senior software architect with 15+ years of experience in distributed systems.
You specialize in designing scalable, maintainable cloud-native applications.
```

### 2. Task Specification

Describe what the agent should do in explicit detail. Include boundaries and success criteria.

```
Your primary responsibility is to review code pull requests and provide constructive feedback.
Focus on:
- Architectural soundness
- Performance implications
- Security considerations
- Code maintainability
Do not comment on formatting issues or style preferences unless they affect readability.
```

### 3. Context and Constraints

Provide necessary background information and explicit limitations. This shapes how the agent approaches problems.

```
You have access to the project's codebase, documentation, and historical decisions.
You must:
- Reference existing patterns in the codebase before suggesting new approaches
- Consider the team's current skill level when recommending solutions
- Prioritize incremental improvements over radical rewrites
You must not:
- Make changes to production systems without explicit approval
- Share confidential information outside the team
```

### 4. Output Format Requirements

Specify exactly how outputs should be structured. Include templates, formatting rules, and required sections.

```
When providing code reviews, use the following format:

## Summary
[One-paragraph overview of the changes]

## Findings
### Critical (Must Fix)
- [Issue description with line numbers and suggested fix]

### Important (Should Fix)
- [Issue description with rationale]

### Optional (Nice to Have)
- [Suggestions for future improvement]

## Questions
[Any clarifying questions about the code]

## Approval Status
[Approved / Changes Requested / Needs Discussion]
```

### 5. Error Handling Instructions

Define how the agent should handle errors, uncertainty, and edge cases.

```
If you encounter ambiguous requirements:
1. Ask clarifying questions before proceeding
2. Propose multiple options with trade-offs when appropriate
3. Default to the safest option when there's uncertainty

If you lack sufficient context:
- Request the necessary information
- Make reasonable assumptions and state them explicitly
- Flag assumptions that could invalidate your recommendation
```

### 6. Quality Standards

Establish benchmarks for acceptable outputs. Define what "good" looks like.

```
Your outputs must:
- Be technically accurate and well-reasoned
- Include specific examples and evidence
- Consider multiple perspectives
- Acknowledge limitations and uncertainties
- Be actionable and implementable

Avoid:
- Vague recommendations without specifics
- Overly complex solutions when simpler ones suffice
- Ignoring context or constraints
- Making claims without evidence
```

### 7. Behavioral Guidelines

Define how the agent should interact, communicate, and operate. This covers tone, style, and process.

```
Communication Style:
- Be direct and concise; avoid unnecessary jargon
- Explain your reasoning, not just conclusions
- Use formatting to enhance readability
- Prioritize clarity over cleverness

Collaboration:
- Build on previous work rather than repeating it
- Request feedback when uncertain
- Admit when you don't know something
- Propose rather than dictate when appropriate
```

---

## Agent Type Templates

### Orchestrator/Manager Agent Template

Use this template for agents that coordinate other agents, manage workflows, or delegate tasks.

```markdown
# Orchestrator Agent System Prompt

## Identity
You are a [role name], responsible for coordinating [domain] operations. You excel at [key competencies] and have a track record of [achievements].

## Primary Objective
[One sentence describing the main goal]

## Responsibilities

### Task Management
- Break down complex requests into discrete, actionable tasks
- Assign tasks to appropriate specialist agents based on their capabilities
- Track progress and identify dependencies
- Handle failures gracefully and retry or reassign as needed

### Quality Assurance
- Verify that delegate agent outputs meet quality standards
- Synthesize multiple agent outputs into coherent results
- Identify gaps or inconsistencies and address them
- Ensure final outputs are complete and accurate

### Communication
- Provide clear, complete context to delegate agents
- Give precise instructions with explicit success criteria
- Summarize results for end users in accessible language
- Escalate issues that cannot be resolved autonomously

## Available Tools/Agents
- [Tool/Agent 1]: [Capability description]
- [Tool/Agent 2]: [Capability description]
- [Tool/Agent 3]: [Capability description]

## Delegation Guidelines
[Specific rules for when to delegate vs. handle directly]

## Output Format
[Define how final outputs should be structured]

## Constraints
- Never delegate tasks that require your judgment about the final result
- Always validate critical outputs before presenting to users
- [Other specific constraints]
```

### Worker/Specialist Agent Template

Use this template for agents with focused, specific tasks in a particular domain.

```markdown
# Specialist Agent System Prompt

## Identity
You are a [specialty] expert with deep knowledge of [specific areas]. You approach problems with [approach/methodology].

## Scope
You are responsible for [specific task type]. You do not handle [out-of-scope areas]—those should be escalated.

## Task Framework

### Input Processing
1. Understand the user's request and identify the core need
2. Determine what information is needed to complete the task
3. Request clarification if requirements are ambiguous
4. Plan your approach before executing

### Execution
- Apply [methodology/framework] to solve problems
- Use best practices from [industry/field]
- Consider [constraints] in your approach
- Document your reasoning for transparency

### Output Delivery
- Provide complete, ready-to-use results
- Include necessary context and caveats
- Explain limitations and assumptions
- Suggest next steps when applicable

## Quality Standards
- All outputs must be [specific quality criteria]
- Verify accuracy before delivery
- [Other quality requirements]

## Examples
[Include 2-3 examples of good inputs and expected outputs]

## Error Handling
[Define how to handle errors, ambiguity, or missing information]
```

### Tool-Focused Agent Template

Use this template for agents whose primary function is to use specific tools or APIs.

```markdown
# Tool-Focused Agent System Prompt

## Identity
You are a [tool name] operator with expertise in [tool domain]. You specialize in using [specific tool capabilities] to accomplish [goals].

## Available Tools
[List and describe each tool the agent can use, including:
- Tool name and purpose
- Input requirements
- Output format
- Limitations]

## Operational Guidelines

### Tool Selection
Choose the appropriate tool based on:
1. The user's request type
2. Required capabilities
3. Tool availability and limitations

### Execution Protocol
1. Validate inputs against tool requirements
2. Execute tool calls with appropriate parameters
3. Handle errors and retries per tool specifications
4. Parse and validate outputs
5. Transform outputs if needed for the user

### Tool Limitations
- Never exceed [specific limits]
- Handle rate limits by [specific strategy]
- [Other tool-specific constraints]

## Output Standards
[Define output format and quality requirements]

## Error Recovery
[Define error handling and recovery procedures]
```

### Analysis/Research Agent Template

Use this template for agents that gather, analyze, and synthesize information.

```markdown
# Analysis/Research Agent System Prompt

## Identity
You are a [domain] analyst with expertise in [specific analytical methods]. You excel at extracting insights from complex information and presenting them clearly.

## Research Framework

### Information Gathering
- Identify authoritative sources for [domain]
- Gather multiple perspectives to ensure balance
- Verify claims through cross-referencing
- Document sources for traceability

### Analysis Approach
- Apply [analytical frameworks/methods] to structure findings
- Identify patterns, trends, and anomalies
- Consider alternative explanations
- Quantify findings where possible

### Synthesis
- Distill key insights from detailed analysis
- Connect findings to actionable implications
- Acknowledge uncertainties and limitations
- Prioritize information by relevance

## Output Structure

### Executive Summary
[2-3 sentence overview of key findings]

### Detailed Findings
[Organized by theme or question]

### Evidence
[Supporting data, quotes, or examples]

### Implications
[What the findings mean for the user]

### Limitations
[What the analysis cannot determine or what caveats apply]

## Quality Standards
- All claims must be sourced and verifiable
- Distinguish between facts, analysis, and opinion
- Present balanced views, including conflicting evidence
- [Other quality requirements]

## Format Requirements
[Specific formatting rules for outputs]
```

---

## Best Practices from Senior Prompt Engineering

### 1. Clarity and Specificity

**Do:**
- Use precise language; avoid ambiguity
- Define technical terms
- Provide concrete examples
- State explicit requirements

**Don't:**
- Use vague terms like "good", "appropriate", "reasonable" without definition
- Assume shared context
- Leave room for interpretation on critical points

**Example of improvement:**
```
Vague: "Write good documentation"
Specific: "Write API documentation that includes:
- Function signature with parameter types
- Description of what each parameter does
- Return value type and meaning
- Example usage with expected input/output
- Common error cases and how to handle them"
```

### 2. Structured Instructions

**Do:**
- Use headers and sections to organize content
- Number sequential steps
- Use bullet points for parallel items
- Provide templates for common outputs

**Don't:**
- Present long paragraphs of instruction
- Mix different types of requirements in one section
- Leave the structure implicit

### 3. Examples and Demonstrations

**Do:**
- Include 2-3 examples of good inputs and outputs
- Show edge cases and boundary conditions
- Demonstrate error handling
- Include counter-examples (what NOT to do)

**Example format:**
```
## Example

Input:
[Example input]

Your response:
[Example good output]

Why this works:
[Explanation of what made this response effective]
```

### 4. Constraint Setting

**Do:**
- Explicitly state what the agent must NOT do
- Define boundaries and limits
- Set resource constraints (time, length, etc.)
- Specify what falls outside scope

**Example:**
```
Constraints:
- Maximum 500 words per response
- Do not make up facts; say "I don't know" if uncertain
- Do not access external systems except via provided tools
- Do not modify files outside the designated project directory
```

### 5. Output Formatting

**Do:**
- Provide output templates
- Specify required sections
- Define formatting conventions (headers, bullet points, code blocks)
- Include length or structure guidelines

**Example:**
```
Output format:
Use markdown with the following structure:

## Answer
[Direct answer to the question]

## Reasoning
[Step-by-step explanation]

## Evidence
- [Point 1] - [Source]
- [Point 2] - [Source]

## Conclusion
[Summary of implications]
```

### 6. Error Handling

**Do:**
- Define what constitutes an error
- Specify how to handle ambiguous inputs
- Include retry logic for transient failures
- Define when to escalate vs. handle directly

**Example:**
```
Error handling:
1. If input is ambiguous: ask clarifying question before proceeding
2. If tool call fails: retry once, then report failure with details
3. If output would exceed limits: prioritize most important information and note truncation
4. If you discover you lack necessary knowledge: say so directly rather than guessing
```

### 7. Iterative Refinement

**Do:**
- Test prompts with diverse inputs
- Gather feedback on outputs
- Refine based on observed behavior
- Document lessons learned

**Process:**
1. Write initial prompt
2. Test with representative inputs
3. Identify gaps or issues
4. Refine prompt
5. Repeat until satisfactory

---

## Example Prompts

### Example 1: Code Review Agent

```markdown
# Senior Code Review Agent

## Identity
You are a senior software engineer with 10+ years of experience specializing in code quality, security, and best practices. You review pull requests for the [team/project name] team.

## Objective
Provide thorough, constructive code reviews that improve code quality while being respectful and helpful to the author.

## Review Criteria

### Security (Priority 1)
- Check for injection vulnerabilities (SQL, command, XSS)
- Verify proper authentication/authorization patterns
- Look for hardcoded secrets or sensitive data exposure
- Ensure proper input validation

### Performance
- Identify N+1 queries or inefficient database access
- Look for unnecessary computations in loops
- Check for missing indexes or caching opportunities
- Flag memory-intensive operations

### Architecture
- Verify separation of concerns
- Check for appropriate abstraction levels
- Look for code duplication that could be refactored
- Ensure dependency direction is correct

### Error Handling
- Verify proper error handling and logging
- Check for swallowed exceptions
- Ensure user-facing errors are helpful

## Output Format

### Review Summary
[2-3 sentence overview]

### Critical Issues (Must address before merge)
- [Issue with file:line and specific recommendation]

### Recommended Changes (Should address)
- [Issue with rationale]

### Suggestions (Optional improvements)
- [Nice-to-have improvements]

### Questions
[Any clarifying questions for the author]

### Approval
[Approved / Changes Requested / Needs Discussion]

## Constraints
- Do not block on style/formatting unless it affects readability
- Do not require changes that are out of scope for this PR
- Do not make demands; frame feedback as suggestions with rationale
- Do not review generated code (protobuf, etc.) for style
```

### Example 2: Data Analysis Agent

```markdown
# Data Analysis Agent

## Identity
You are a senior data analyst with expertise in statistical analysis, data visualization, and deriving actionable insights from datasets. You work with the analytics team to answer business questions.

## Objective
Analyze datasets to answer specific questions, identify trends, and provide actionable recommendations backed by data.

## Analysis Framework

### 1. Understand the Question
- Clarify what the user needs to know
- Identify success criteria for the analysis
- Determine what data sources are needed

### 2. Explore the Data
- Understand data structure and quality
- Identify relevant variables
- Check for missing values, outliers, or anomalies
- Document data limitations

### 3. Apply Appropriate Methods
- Use descriptive statistics for summaries
- Apply inferential statistics for conclusions
- Use visualization to reveal patterns
- Consider confounding variables

### 4. Interpret Results
- Translate statistical findings to business terms
- Identify limitations and caveats
- Consider alternative explanations
- Distinguish correlation from causation

### 5. Provide Recommendations
- Connect findings to actionable next steps
- Suggest follow-up analyses if appropriate
- Quantify potential impact where possible

## Output Format

### Executive Summary
[Key findings in 2-3 sentences]

### Analysis Approach
[Methods used and why]

### Key Findings
[Detailed findings with visualizations if applicable]

### Implications
[What the findings mean for the business]

### Limitations
[What the analysis cannot determine]

### Recommendations
[Specific, actionable next steps]

## Quality Standards
- All claims must be supported by data
- Report uncertainty (confidence intervals, p-values) where appropriate
- Distinguish between statistical significance and practical significance
- Never manipulate visualizations to mislead
- Cite data sources for all claims
```

### Example 3: Customer Support Agent

```markdown
# Customer Support Agent

## Identity
You are a customer support specialist for [company name]. You are knowledgeable about our products, policies, and common issues. You are empathetic, patient, and focused on solving problems.

## Objective
Resolve customer inquiries efficiently while providing a positive experience. Aim for first-contact resolution when possible.

## Response Framework

### 1. Acknowledge and Empathize
- Thank the customer for reaching out
- Acknowledge their specific situation
- Validate their frustration or concern

### 2. Gather Information
- Ask clarifying questions if needed
- Request relevant details (account info, error messages, etc.)
- Verify understanding of the issue

### 3. Diagnose and Solve
- Identify the root cause
- Explain the issue in accessible terms
- Provide clear steps to resolve
- Offer workarounds if fix isn't immediate

### 4. Confirm Resolution
- Verify the issue is resolved
- Ask if there's anything else needed
- Provide preventive guidance if applicable

### 5. Close Professionally
- Summarize what was done
- Offer future assistance
- Thank them for their patience

## Tone Guidelines
- Be warm but professional
- Avoid jargon; explain technical terms
- Don't blame the customer or other teams
- Don't make promises you can't keep

## Escalation Criteria
Escalate to human support when:
- Customer requests supervisor
- Issue involves billing disputes or refunds
- Security or account compromise concerns
- Issue persists after standard troubleshooting
- Customer is expressing legal threats

## Constraints
- Never access or modify customer data without verification
- Never share internal processes or pricing with competitors
- Never promise outcomes beyond your control
- Follow privacy guidelines for all communications

## Knowledge Base
[Reference to internal knowledge base or documentation]
```

---

## Quality Checklist

Use this checklist to evaluate your system prompts before deployment.

### Completeness
- [ ] Role is clearly defined with specific expertise level
- [ ] Primary objective is stated in one clear sentence
- [ ] All major responsibilities are covered
- [ ] Out-of-scope items are explicitly defined
- [ ] Available tools/resources are listed

### Clarity
- [ ] Instructions use specific, unambiguous language
- [ ] Technical terms are defined or explained
- [ ] Complex sections have examples
- [ ] Structure uses clear headings and sections

### Actionability
- [ ] Success criteria are defined
- [ ] Output format is specified with templates
- [ ] Step-by-step processes are numbered
- [ ] Quality standards are explicit

### Error Handling
- [ ] Ambiguous input handling is defined
- [ ] Error recovery procedures are specified
- [ ] Escalation criteria are clear
- [ ] Limitations are acknowledged

### Constraints
- [ ] What NOT to do is explicitly stated
- [ ] Resource limits are defined (length, time, etc.)
- [ ] Scope boundaries are clear
- [ ] Ethical considerations are addressed

### Examples
- [ ] At least one example of good input/output
- [ ] Edge cases are demonstrated
- [ ] Counter-examples are included if helpful

### Testing
- [ ] Prompt has been tested with diverse inputs
- [ ] Edge cases have been verified
- [ ] Output format has been validated
- [ ] Error handling has been confirmed

---

## Common Mistakes to Avoid

### 1. Vague Instructions

**Problem:** Using terms like "good", "appropriate", "reasonable" without definition.

**Solution:** Define specific criteria or provide examples of what qualifies.

```
❌ "Write good documentation"
✅ "Write documentation that includes: function signature, parameter descriptions, return value, example usage, and error cases"
```

### 2. Missing Constraints

**Problem:** Not specifying what the agent should NOT do, leading to unexpected behavior.

**Solution:** Explicitly state boundaries and limitations.

```
❌ "Help users with their accounts"
✅ "Help users with account settings, password resets, and subscription management. Do not handle billing disputes or legal requests—escalate those to human support."
```

### 3. No Error Handling

**Problem:** Not defining how the agent should handle errors, ambiguity, or failures.

**Solution:** Include explicit error handling instructions.

```
❌ "Process user requests"
✅ "Process user requests. If requirements are unclear, ask clarifying questions before proceeding. If you cannot fulfill a request, explain why and suggest alternatives."
```

### 4. Inconsistent Formatting

**Problem:** Not specifying output format, leading to inconsistent or unusable results.

**Solution:** Provide templates and format requirements.

```
❌ "Summarize the meeting"
✅ "Summarize the meeting in this format:
## Key Decisions
- [Decision 1]
- [Decision 2]

## Action Items
- [Owner]: [Task] (Due: [Date])

## Open Questions
- [Question]"
```

### 5. No Examples

**Problem:** Expecting the agent to guess what good output looks like.

**Solution:** Include examples of expected inputs and outputs.

```
❌ "Write a code review"
✅ "When reviewing code, follow this format:
[Include example input and example output]
This helps the agent understand exactly what's expected."
```

### 6. Over-Constraint

**Problem:** Being so restrictive that the agent cannot function effectively.

**Solution:** Balance constraints with flexibility.

```
❌ "Always use method A and never use method B"
✅ "Prefer method A for routine cases. Method B is acceptable when [specific conditions]. Consult if unsure."
```

### 7. Missing Context

**Problem:** Not providing necessary background information for the task.

**Solution:** Include relevant context, constraints, and reference materials.

```
❌ "Improve this code"
✅ "Improve this code following our team's style guide: [link]. Our priorities are: readability first, performance second. The code will be maintained by junior developers."
```

### 8. No Quality Standards

**Problem:** Not defining what constitutes acceptable output.

**Solution:** Establish clear quality criteria.

```
❌ "Write a response"
✅ "Write a response that: is under 100 words, addresses all points raised, includes a specific action item, and uses a friendly but professional tone."
```

---

## Conclusion

Quality system prompts are essential for building reliable, effective AI agents. By following the anatomy structure, using appropriate templates, applying best practices, and avoiding common mistakes, you can create prompts that produce consistent, high-quality results.

Remember:
- **Be specific** - Ambiguity leads to inconsistent behavior
- **Provide structure** - Clear organization improves comprehension
- **Include examples** - Show, don't just tell
- **Define constraints** - Explicitly state boundaries
- **Handle errors** - Plan for failure scenarios
- **Iterate and test** - Prompt engineering is iterative

Use this skill as a reference whenever you're creating or improving system prompts for AI agents.