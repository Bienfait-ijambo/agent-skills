# TODO List Examples

This document provides comprehensive examples of good TODO list usage for various workflow scenarios.

---

## Example 1: Simple Linear Workflow

**Scenario:** Read a file, modify it, and write the result.

```json
{
  "filename": "simple-file-update",
  "todos": [
    {
      "task": "Read the current config.json file",
      "assigned_to": "me",
      "status": "pending"
    },
    {
      "task": "Add the new API endpoint configuration",
      "assigned_to": "me",
      "status": "pending",
      "dependencies": ["uuid-of-read-task"]
    },
    {
      "task": "Write the updated config.json file",
      "assigned_to": "me",
      "status": "pending",
      "dependencies": ["uuid-of-modify-task"]
    }
  ]
}
```

**Execution Flow:**
1. Mark task 1 as `in_progress` → Read file → Mark as `completed`
2. Task 2 becomes runnable → Mark `in_progress` → Modify → Mark `completed`
3. Task 3 becomes runnable → Mark `in_progress` → Write → Mark `completed`

---

## Example 2: Parallel Execution Workflow

**Scenario:** Research multiple topics simultaneously, then synthesize.

```json
{
  "filename": "parallel-research",
  "todos": [
    {
      "task": "Research topic A: AI Agent Architecture",
      "assigned_to": "researcher",
      "status": "pending"
    },
    {
      "task": "Research topic B: Multi-Agent Systems",
      "assigned_to": "researcher",
      "status": "pending"
    },
    {
      "task": "Research topic C: Tool Integration Patterns",
      "assigned_to": "researcher",
      "status": "pending"
    },
    {
      "task": "Synthesize all research into comprehensive report",
      "assigned_to": "me",
      "status": "pending",
      "dependencies": ["uuid-task-a", "uuid-task-b", "uuid-task-c"]
    }
  ]
}
```

**Execution Flow:**
1. Tasks 1, 2, 3 are all runnable (no dependencies) → Launch in parallel
2. Wait for all three to complete
3. Task 4 becomes runnable → Synthesize

---

## Example 3: Hierarchical Task Breakdown

**Scenario:** Build a complete multi-agent system.

```json
{
  "filename": "multi-agent-build",
  "todos": [
    {
      "task": "Build Multi-Agent Weather System",
      "assigned_to": "me",
      "status": "pending"
    },
    {
      "task": "Create input node for user queries",
      "assigned_to": "me",
      "status": "pending",
      "parent_id": "uuid-parent"
    },
    {
      "task": "Create manager agent node",
      "assigned_to": "me",
      "status": "pending",
      "parent_id": "uuid-parent",
      "dependencies": ["uuid-input"]
    },
    {
      "task": "Create weather API tool node",
      "assigned_to": "me",
      "status": "pending",
      "parent_id": "uuid-parent",
      "dependencies": ["uuid-manager"]
    },
    {
      "task": "Create geolocation tool node",
      "assigned_to": "me",
      "status": "pending",
      "parent_id": "uuid-parent",
      "dependencies": ["uuid-manager"]
    },
    {
      "task": "Create model node (GPT-4)",
      "assigned_to": "me",
      "status": "pending",
      "parent_id": "uuid-parent",
      "dependencies": ["uuid-manager"]
    },
    {
      "task": "Connect all nodes with edges",
      "assigned_to": "me",
      "status": "pending",
      "parent_id": "uuid-parent",
      "dependencies": ["uuid-weather-tool", "uuid-geo-tool", "uuid-model"]
    },
    {
      "task": "Validate JSON structure",
      "assigned_to": "me",
      "status": "pending",
      "parent_id": "uuid-parent",
      "dependencies": ["uuid-connect"]
    }
  ]
}
```

**Visualization:**
```
Build Multi-Agent Weather System (parent)
├── Create input node
├── Create manager agent (depends on input)
│   ├── Create weather API tool
│   ├── Create geolocation tool
│   └── Create model node
└── Connect all nodes (depends on all tools)
    └── Validate JSON structure
```

---

## Example 4: Dependency Resolution

**Scenario:** Build a feature that requires multiple prerequisites.

```json
{
  "filename": "feature-with-prerequisites",
  "todos": [
    {
      "task": "Set up database connection",
      "assigned_to": "me",
      "status": "pending"
    },
    {
      "task": "Create database schema",
      "assigned_to": "me",
      "status": "pending",
      "dependencies": ["uuid-db-connection"]
    },
    {
      "task": "Seed initial data",
      "assigned_to": "me",
      "status": "pending",
      "dependencies": ["uuid-schema"]
    },
    {
      "task": "Build API endpoints",
      "assigned_to": "coder",
      "status": "pending",
      "dependencies": ["uuid-schema"]
    },
    {
      "task": "Create frontend components",
      "assigned_to": "frontend-dev",
      "status": "pending",
      "dependencies": ["uuid-api"]
    },
    {
      "task": "Integration testing",
      "assigned_to": "tester",
      "status": "pending",
      "dependencies": ["uuid-frontend", "uuid-seed"]
    },
    {
      "task": "Deploy to production",
      "assigned_to": "me",
      "status": "pending",
      "dependencies": ["uuid-testing"]
    }
  ]
}
```

**Dependency Graph:**
```
db-connection
    └── schema
        ├── seed-data ──────────────┐
        └── api-endpoints           │
            └── frontend-components │
                └── testing ←───────┘
                    └── deploy
```

---

## Example 5: Handling Blocked Tasks

**Scenario:** Task gets blocked due to missing information.

**Initial State:**
```json
{
  "filename": "blocked-task-workflow",
  "todos": [
    {
      "id": "uuid-1",
      "task": "Fetch user data from API",
      "assigned_to": "me",
      "status": "pending"
    },
    {
      "id": "uuid-2",
      "task": "Process user data",
      "assigned_to": "me",
      "status": "pending",
      "dependencies": ["uuid-1"]
    },
    {
      "id": "uuid-3",
      "task": "Generate user report",
      "assigned_to": "me",
      "status": "pending",
      "dependencies": ["uuid-2"]
    }
  ]
}
```

**Blocking Event:**
API returns 401 Unauthorized - missing API key.

**Update:**
```json
{
  "filename": "blocked-task-workflow.todos.json",
  "updates": [
    {
      "id": "uuid-1",
      "status": "blocked",
      "task": "Fetch user data from API - BLOCKED: API key required. Need user to provide API_KEY environment variable."
    }
  ]
}
```

**Resolution:**
User provides API key.

**Unblock:**
```json
{
  "filename": "blocked-task-workflow.todos.json",
  "updates": [
    {
      "id": "uuid-1",
      "status": "pending",
      "task": "Fetch user data from API"
    }
  ]
}
```

---

## Example 6: Research and Synthesis Workflow

**Scenario:** Conduct research with multiple phases and final synthesis.

```json
{
  "filename": "research-synthesis",
  "todos": [
    {
      "task": "Phase 1: Define research questions",
      "assigned_to": "me",
      "status": "pending"
    },
    {
      "task": "Phase 2a: Research primary sources",
      "assigned_to": "researcher",
      "status": "pending",
      "dependencies": ["uuid-phase1"]
    },
    {
      "task": "Phase 2b: Research secondary sources",
      "assigned_to": "researcher",
      "status": "pending",
      "dependencies": ["uuid-phase1"]
    },
    {
      "task": "Phase 2c: Research case studies",
      "assigned_to": "researcher",
      "status": "pending",
      "dependencies": ["uuid-phase1"]
    },
    {
      "task": "Phase 3: Analyze and cross-reference findings",
      "assigned_to": "analyst",
      "status": "pending",
      "dependencies": ["uuid-phase2a", "uuid-phase2b", "uuid-phase2c"]
    },
    {
      "task": "Phase 4: Draft research report",
      "assigned_to": "writer",
      "status": "pending",
      "dependencies": ["uuid-phase3"]
    },
    {
      "task": "Phase 5: Review and refine report",
      "assigned_to": "reviewer",
      "status": "pending",
      "dependencies": ["uuid-phase4"]
    },
    {
      "task": "Phase 6: Finalize and export report",
      "assigned_to": "me",
      "status": "pending",
      "dependencies": ["uuid-phase5"]
    }
  ]
}
```

**Execution Timeline:**
```
Phase 1: Define questions
    ↓
Phase 2a, 2b, 2c: Research (parallel)
    ↓
Phase 3: Analyze (after all research complete)
    ↓
Phase 4: Draft report
    ↓
Phase 5: Review
    ↓
Phase 6: Finalize
```

---

## Example 7: Multi-Agent Delegation Workflow

**Scenario:** Manager delegates tasks to multiple specialized subagents.

```json
{
  "filename": "multi-agent-delegation",
  "todos": [
    {
      "task": "Analyze project requirements",
      "assigned_to": "me",
      "status": "pending"
    },
    {
      "task": "Design system architecture",
      "assigned_to": "architect",
      "status": "pending",
      "dependencies": ["uuid-analyze"]
    },
    {
      "task": "Implement backend API",
      "assigned_to": "backend-dev",
      "status": "pending",
      "dependencies": ["uuid-design"]
    },
    {
      "task": "Implement frontend UI",
      "assigned_to": "frontend-dev",
      "status": "pending",
      "dependencies": ["uuid-design"]
    },
    {
      "task": "Write unit tests",
      "assigned_to": "tester",
      "status": "pending",
      "dependencies": ["uuid-backend", "uuid-frontend"]
    },
    {
      "task": "Write documentation",
      "assigned_to": "writer",
      "status": "pending",
      "dependencies": ["uuid-backend", "uuid-frontend"]
    },
    {
      "task": "Integration and deployment",
      "assigned_to": "devops",
      "status": "pending",
      "dependencies": ["uuid-tests", "uuid-docs"]
    }
  ]
}
```

**Subagent Assignment Table:**

| Task | Subagent | Skills |
|------|----------|--------|
| Design architecture | architect | System design, scalability |
| Backend API | backend-dev | Node.js, databases, APIs |
| Frontend UI | frontend-dev | React, CSS, UX |
| Unit tests | tester | Jest, testing patterns |
| Documentation | writer | Technical writing, API docs |
| Deployment | devops | Docker, CI/CD, cloud |

---

## Example 8: Error Recovery Workflow

**Scenario:** Task fails and needs retry logic.

**Initial Attempt:**
```json
{
  "filename": "error-recovery",
  "todos": [
    {
      "id": "uuid-1",
      "task": "Download large dataset",
      "assigned_to": "me",
      "status": "in_progress"
    },
    {
      "id": "uuid-2",
      "task": "Process dataset",
      "assigned_to": "me",
      "status": "pending",
      "dependencies": ["uuid-1"]
    }
  ]
}
```

**Error Occurs:**
Download fails due to network timeout.

**Update:**
```json
{
  "filename": "error-recovery.todos.json",
  "updates": [
    {
      "id": "uuid-1",
      "status": "blocked",
      "task": "Download large dataset - BLOCKED: Network timeout. Will retry with smaller batch size."
    }
  ]
}
```

**Recovery Strategy:**
```json
{
  "filename": "error-recovery.todos.json",
  "updates": [
    {
      "id": "uuid-1",
      "status": "pending",
      "task": "Download dataset (batch 1 of 5)"
    }
  ]
}
```

**Add Recovery Tasks:**
```json
{
  "filename": "error-recovery.todos.json",
  "updates": [
    {
      "id": "uuid-1",
      "status": "completed"
    }
  ]
}
```

Then add new tasks for remaining batches.

---

## Example 9: Context Window Management

**Scenario:** Large task that might fill context window.

**Strategy:** Create checkpoint TODOs to enable resumption.

```json
{
  "filename": "large-project-checkpoints",
  "todos": [
    {
      "task": "CHECKPOINT 1: Project setup complete",
      "assigned_to": "me",
      "status": "pending"
    },
    {
      "task": "Implement core module A",
      "assigned_to": "me",
      "status": "pending",
      "dependencies": ["uuid-checkpoint-1"]
    },
    {
      "task": "CHECKPOINT 2: Core module A complete",
      "assigned_to": "me",
      "status": "pending",
      "dependencies": ["uuid-module-a"]
    },
    {
      "task": "Implement core module B",
      "assigned_to": "me",
      "status": "pending",
      "dependencies": ["uuid-checkpoint-2"]
    },
    {
      "task": "CHECKPOINT 3: Core module B complete",
      "assigned_to": "me",
      "status": "pending",
      "dependencies": ["uuid-module-b"]
    },
    {
      "task": "Integration testing",
      "assigned_to": "me",
      "status": "pending",
      "dependencies": ["uuid-checkpoint-3"]
    },
    {
      "task": "CHECKPOINT 4: Testing complete",
      "assigned_to": "me",
      "status": "pending",
      "dependencies": ["uuid-testing"]
    },
    {
      "task": "Final deployment",
      "assigned_to": "me",
      "status": "pending",
      "dependencies": ["uuid-checkpoint-4"]
    }
  ]
}
```

**Why Checkpoints Matter:**
- If context fills, the last completed checkpoint shows where to resume
- Checkpoints act as save points in a long workflow
- Each checkpoint can be a natural context boundary

---

## Example 10: Complete Update Sequence

**Full lifecycle of a single task:**

```json
// Step 1: Create TODO
{
  "filename": "lifecycle-example",
  "todos": [
    {
      "task": "Read configuration file",
      "assigned_to": "me",
      "status": "pending"
    }
  ]
}

// Step 2: Start task
{
  "filename": "lifecycle-example.todos.json",
  "updates": [
    {
      "id": "uuid-from-creation",
      "status": "in_progress"
    }
  ]
}

// Step 3: Complete task
{
  "filename": "lifecycle-example.todos.json",
  "updates": [
    {
      "id": "uuid-from-creation",
      "status": "completed"
    }
  ]
}
```

**Status Transition Diagram:**
```
┌─────────┐     start      ┌─────────────┐     finish     ┌───────────┐
│ pending │ ───────────────▶│ in_progress │ ──────────────▶│ completed │
└─────────┘                 └─────────────┘                └───────────┘
     ▲                            │
     │         blocked             │
     │◀────────────────────────────┘
     │                            │
     │        resolved             │
     └────────────────────────────┘
```

---

## Summary: Best Practices Recap

1. **Always create TODO for 3+ step tasks**
2. **Update status immediately after each action**
3. **Use dependencies to enforce order**
4. **Use `in_progress` to show active work**
5. **Use `blocked` to flag issues**
6. **Use `get_next_runnable_tasks` to find ready tasks**
7. **Use checkpoints for long workflows**
8. **Read TODO before updating to get correct UUIDs**
9. **Be specific in task descriptions**
10. **Assign to correct entity (me vs subagent)**